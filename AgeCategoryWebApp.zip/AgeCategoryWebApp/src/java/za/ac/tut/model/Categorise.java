/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model;

/**
 *
 * @author Lindi
 */
public class Categorise {
    private int age;

    public Categorise(int age) {
        this.age = age;
    }
    
    public String ageCategory(){
        String category;
        if(age >= 0 && age <=14){
            category = "child";
        }else if(age >= 15 && age <=24){
            category = "Youth";
        }else if(age >= 25 && age <= 64){
            category = "Adult";
        }else{
            category = "Senior";
        }
        return category;
    }
    
}
